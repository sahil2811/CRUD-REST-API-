const mongoose = require('mongoose')
const alienschema = new mongoose.Schema({
    name:{
        type:String,
        required:true,
        default:"Sahil" 
    },
    tech:{
        type:String,
        required:true,
        default:"Python"
    },
    sub:{
        type:Boolean,
        required:true,
        default:false
    }
})

module.exports = mongoose.model('Alien',alienschema)